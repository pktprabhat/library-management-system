<?php

	require("../include/layout.php");

	render_html("main");
	render_header("RGSC LIBRARY");
?>

<html>
<head>
<title>Untitled-1</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- Save for Web Slices (Untitled-1) -->
<table id="Table_01" width="1009" height="721" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="15">
			<img src="images/first_01.gif" width="1008" height="14" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="14" alt=""></td>
	</tr>
	<tr>
		<td colspan="11" rowspan="2">
			<img src="images/first_02.gif" width="735" height="314" alt=""></td>
		<td colspan="3">
			<a href="http://www.bhu.ac.in">
				<img src="images/Untitled-1_03.gif" width="260" height="267" border="0" alt=""></a></td>
		<td rowspan="9">
			<img src="images/first_04.gif" width="13" height="706" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="267" alt=""></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="images/first_05.gif" width="260" height="47" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="47" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" rowspan="3">
			<img src="images/first_06.gif" width="68" height="179" alt=""></td>
		<td>
			<a href="issue.php">
				<img src="images/Untitled-1_03-08.gif" width="150" height="150" border="0" alt=""></a></td>
		<td rowspan="7">
			<img src="images/first_08.gif" width="57" height="392" alt=""></td>
		<td>
			<a href="returnbook.php">
				<img src="images/Untitled-1_05.gif" width="170" height="150" border="0" alt=""></a></td>
		<td colspan="2" rowspan="3">
			<img src="images/first_10.gif" width="47" height="179" alt=""></td>
		<td colspan="2" rowspan="2">
			<a href="addstu.php">
				<img src="images/Untitled-1_07.gif" width="164" height="166" border="0" alt=""></a></td>
		<td colspan="2" rowspan="4">
			<img src="images/first_12.gif" width="79" height="208" alt=""></td>
		<td colspan="2" rowspan="3">
			<a href="deletestu.php">
				<img src="images/Untitled-1_09.gif" width="194" height="179" border="0" alt=""></a></td>
		<td rowspan="7">
			<img src="images/first_14.gif" width="66" height="392" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="150" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2">
			<img src="images/first_15.gif" width="150" height="29" alt=""></td>
		<td rowspan="2">
			<img src="images/first_16.gif" width="170" height="29" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="16" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" rowspan="2">
			<img src="images/first_17.gif" width="164" height="42" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="13" alt=""></td>
	</tr>
	<tr>
		<td rowspan="4">
			<img src="images/first_18.gif" width="53" height="213" alt=""></td>
		<td colspan="2" rowspan="3">
			<a href="addbook.php">
				<img src="images/Untitled-1_15.gif" width="165" height="168" border="0" alt=""></a></td>
		<td colspan="2" rowspan="3">
			<a href="deletebook.php">
				<img src="images/Untitled-1_16.gif" width="198" height="168" border="0" alt=""></a></td>
		<td rowspan="4">
			<img src="images/first_21.gif" width="19" height="213" alt=""></td>
		<td rowspan="2">
			<img src="images/first_22.gif" width="23" height="44" alt=""></td>
		<td rowspan="4">
			<img src="images/first_23.gif" width="171" height="213" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="29" alt=""></td>
	</tr>
	<tr>
		<td rowspan="3">
			<img src="images/first_24.gif" width="14" height="184" alt=""></td>
		<td colspan="2" rowspan="2">
			<a href="list1.php">
				<img src="images/Untitled-1_21.gif" width="171" height="139" border="0" alt=""></a></td>
		<td rowspan="3" colspan="2">
		<a href="../logout.php">
			<img src="images/first_26.gif" width="58" height="184" alt=""></a></td>
		<td>
			<img src="images/spacer.gif" width="1" height="15" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2">
			<img src="images/first_27.gif" width="23" height="169" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="124" alt=""></td>
	</tr>
	<tr>
		<td colspan="2">
			<img src="images/first_28.gif" width="165" height="45" alt=""></td>
		<td colspan="2">
			<img src="images/first_29.gif" width="198" height="45" alt=""></td>
		<td colspan="2">
			<img src="images/first_30.gif" width="171" height="45" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="45" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/spacer.gif" width="53" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="15" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="150" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="57" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="170" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="28" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="19" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="14" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="150" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="21" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="58" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="23" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="171" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="66" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="13" height="1" alt=""></td>
		<td></td>
	</tr>
</table>
</body>
</html>
<?php
render_footer();
	get_css("../style/frm.css");
	get_css("../style/layout.css");
?>
