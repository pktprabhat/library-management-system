<?php

function render_html($title)
{
	echo '<!doctype html><html><head><title>'.$title.'</title>';
};

function render_header($head)
{
	echo '</head><body><div class="header">CENTRAL LIBRARY<br><w>'.$head.'</w></div>';
};

function render_footer()
{
	echo '<div class="footer"><a href="../about.php">About!</a></div></body></html>';
};

function get_css($addr)
{
	echo '<link rel="stylesheet" type="text/css" href="'.$addr.'" />';
};

?>