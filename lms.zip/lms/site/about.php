<?php

	require("include/layout.php");

	render_html("About");
	render_header("RGSC LIBRARY");
?>
	<h2>RGSC LIBRARY MANAGEMENT SYSTEM</h2>
	<h4>developed by prabhat kumar (mca 3 sem)</h4>
<?php
render_footer();

?>